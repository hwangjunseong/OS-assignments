#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "spinlock.h"
#include "slab.h"
#include<stdbool.h>

struct {
	struct spinlock lock;
	struct slab slab[NSLAB];
} stable;

//reason divide 8 : 1byte ->8bit

//some bit 0 or 1 check?
bool get_bit(char * bitmap, int i) {
    return ((bitmap[i/8] & (1 << (i%8))) != 0);
}
//or
void set_bit(char * bitmap, int i) {
    bitmap[i/8]= bitmap[i/8] | (1 << (i%8));
}
//some bit 1-> 0
void clear_bit(char*bitmap, int i) {
    int mask = ~(1 << (i%8));
    bitmap[i/8] = bitmap[i/8] & mask;
}


void slabinit(){
	/* fill in the blank */
	struct slab *s;

	int slabbyte = 16;
	int numofslab = 0;
        for(s = stable.slab; s < &stable.slab[NSLAB]; s++){
           numofslab = PGSIZE/slabbyte;
           s->size = slabbyte;
	   s->num_pages =  1;//slab allocator page numbers
	   s->num_used_objects = 0;
	   s->num_free_objects = numofslab;
	   s->num_objects_per_page = numofslab;	
	   s->bitmap =  (char*)kalloc();
	   memset(s->bitmap, 0, PGSIZE);
	   
	   //slab cache: slab objects save one page
    	   s->page[0] = (char*)kalloc();
	   slabbyte=slabbyte*2;
	   
        }

}
int nearest(int size){
	if(size<0 || size >2048)
            return 0;
	int nearest_pow_of_2 = 1;
    	while (nearest_pow_of_2 < size)
            nearest_pow_of_2 <<= 1;
        if (nearest_pow_of_2 == size)
            return size;
    	else
            return nearest_pow_of_2;
}

char *kmalloc(int size){
	struct slab *s;
	char * address=0;
        int bytesize = nearest(size);
        if(bytesize==0)
            return 0;
	
	acquire(&stable.lock);
	
 	for(s = stable.slab; s < &stable.slab[NSLAB]; s++){
	    if(s->size == bytesize){
		
		break;   	
	    }
	    
	}
	
	//need new page	
	if(s->num_free_objects==0){
                //page 100 exceed
                if(s->num_pages>=MAX_PAGES_PER_SLAB){
                        release(&stable.lock);
                        return 0;
                }
			
		s->page[s->num_pages] =(char*) kalloc();
		memset(s->page[s->num_pages],0, PGSIZE);
		s->num_pages+=1;
		s->num_free_objects += s->num_objects_per_page;
	 
              	
	}

	//bitmap update
	int mx_bitlen = s->num_pages* s->num_objects_per_page;
	for(int i=0; i<mx_bitlen; i++){
		//check bit i is using or not
		
		//bit i not use
		if(get_bit(s->bitmap, i)== false){
			//page num
			int page_idx = (i/s->num_objects_per_page);
			//page num-> object num
			int page_offset = (i%s->num_objects_per_page);

			//address set
			address = s->page[page_idx]+ (page_offset * s->size);

			//mark bit i is using
			set_bit(s->bitmap, i);
			//make 0
			memset(s->page[s->num_pages], 0, PGSIZE);

			s->num_used_objects +=1;
			s->num_free_objects -=1;
			break;
		}
		
	}



	release(&stable.lock);
	return address;
}

void kmfree(char *addr, int size){
	/* fill in the blank */	
        acquire(&stable.lock);
	struct slab *s;
	for(s = stable.slab; s < &stable.slab[NSLAB]; s++){
            if(s->size >= size){
		
		
	    	break;
	    } 
        }
	int mx_bitlen = s->num_pages* s->num_objects_per_page;
	int total = PGSIZE*8;

	for(int i=0; i<mx_bitlen; i++){
             
            //page num
            int page_idx = (i/s->num_objects_per_page);
            //page num-> object num
            int page_offset = (i%s->num_objects_per_page);
            //find free addr
            if(addr == (s->page[page_idx]+ (page_offset * s->size))){
            	//make 0
            	memset(addr, 0, s->size);
		if(s->num_used_objects>0){	
            	s->num_free_objects+=1;
            	s->num_used_objects-=1;
		}	
           	//clear bitmap
           	clear_bit(s->bitmap, i);
		if(s->num_pages<=1)
			break;
			
	
		int start = page_idx *s->num_objects_per_page;
		for(int a=start; a<start+s->num_objects_per_page; a++){
			if(get_bit(s->bitmap, a)==true){

				release(&stable.lock);
				return;
					
			}
		}
	
			
		kfree(s->page[page_idx]);
					
                s->num_free_objects-=s->num_objects_per_page;
		
		//bitmap move and page move 
			
        	for(int st = start; st<start+s->num_objects_per_page; st++){
                	clear_bit(s->bitmap, st);
        	}
        	for(int m = start+s->num_objects_per_page; m<total; m++){
			
			if((s->bitmap[m/8] & (1<<(m%8)))>>(m%8)){
				set_bit(s->bitmap, m-s->num_objects_per_page);
			}else{
				clear_bit(s->bitmap, m-s->num_objects_per_page);
			}
        	}
        	for(int e = total-s->num_objects_per_page; e<total; e++){
        		clear_bit(s->bitmap, e);
        	}

		for(int j=page_idx+1; j<=s->num_pages-1; j++){
			s->page[j-1]= s->page[j];
		}
		s->num_pages-=1;
		break;
      	    }
	    
	    
	}
	
        release(&stable.lock);
	return; 
	
}

/* Helper functions */
void slabdump(){
	cprintf("__slabdump__\n");

	struct slab *s;

	cprintf("size\tnum_pages\tused_objects\tfree_objects\n");

	for(s = stable.slab; s < &stable.slab[NSLAB]; s++){
		cprintf("%d\t%d\t\t%d\t\t%d\n", 
			s->size, s->num_pages, s->num_used_objects, s->num_free_objects);
	}
}

int numobj_slab(int slabid)
{
	return stable.slab[slabid].num_used_objects;
}

int numpage_slab(int slabid)
{
	return stable.slab[slabid].num_pages;
}
